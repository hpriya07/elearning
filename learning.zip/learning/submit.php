<?php
// Start a session
session_start();

// Database connection
$connection = mysqli_connect('localhost', 'root', '1234', 'exceptional', 3307) or die("Database Not connected: " . mysqli_connect_error());

if (isset($_POST['submit'])) {
    // Get form data
    $name = isset($_POST['name']) ? mysqli_real_escape_string($connection, $_POST['name']) : '';
    $mail_id = isset($_POST['mail_id']) ? mysqli_real_escape_string($connection, $_POST['mail_id']) : '';
    $pass = isset($_POST['pass']) ? password_hash($_POST['pass'], PASSWORD_DEFAULT) : ''; // Hash the password for security
    $projects_submit = isset($_POST['projects_submit']) ? mysqli_real_escape_string($connection, $_POST['projects_submit']) : '';
    $school = isset($_POST['school']) ? mysqli_real_escape_string($connection, $_POST['school']) : '';

    // Check if the email already exists in the database
    $checkEmailQuery = "SELECT * FROM user_rankings WHERE mail_id = '$mail_id'";
    $result = mysqli_query($connection, $checkEmailQuery);

    if (mysqli_num_rows($result) > 0) {
        echo "User with this email already exists!";
    } else {
        // SQL query to insert data into the database
        $sql = "INSERT INTO user_rankings (name, mail_id, pass, projects_submit, projects, juxtapose, card_hustle, sprint_pdf, sprint, school)
                VALUES ('$name', '$mail_id', '$pass', '$projects_submit', 0, 0, 0, '', 0, '$school')";

        if (mysqli_query($connection, $sql)) {
            echo "New record created successfully! Project PDF link: <a href='$projects_submit' target='_blank'>$projects_submit</a>";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connection);
        }
    }
}

if (isset($_POST['view_scores'])) {
    $selected_school = isset($_POST['selected_school']) ? mysqli_real_escape_string($connection, $_POST['selected_school']) : '';

    if ($selected_school) {
        $query = "SELECT name, mail_id, projects, school FROM user_rankings WHERE school = '$selected_school'";
        $result = mysqli_query($connection, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<h2>SCORES FOR $selected_school</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Project Points</th>
                        <th>School</th>
                    </tr>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['mail_id']}</td>
                        <td>{$row['projects']}</td>
                        <td>{$row['school']}</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "No records found for $selected_school.";
        }
    }
}

// Close the database connection
mysqli_close($connection);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aqua Edu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('images/background.png')no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333;
        }
        .container {
            width: 80%;
            max-width: 600px;
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
        }
        h2 {
            color: #007bff;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"], select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #f9f9f9; /* Light grey background for table */
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>AQUA EDU PROJECTS</h2>

    <form action="index.php?page=submit" method="post">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>
        
        <label for="mail_id">Email:</label>
        <input type="email" name="mail_id" id="mail_id" required>
        
        <label for="pass">Password:</label>
        <input type="password" name="pass" id="pass" required>
        
        <label for="projects_submit">Project PDF Link:</label>
        <input type="text" name="projects_submit" id="projects_submit" required>
        
        <label for="school">School:</label>
        <select name="school" id="school" required>
            <option value="">Select your school</option>
            <option value="Alpha School">Alpha School</option>
            <option value="Jai Gopal Garodia">Jai Gopal Garodia</option>
            <option value="Jawahar Vidyalaya">Jawahar Vidyalaya</option>
            <option value="Jawahar Vidyalaya">Padma Seshadri Bala Bhavan (PSBB)</option>
            <option value="Jawahar Vidyalaya">Kendriya Vidyalaya, IIT Campus</option>
            <option value="Jawahar Vidyalaya">DAV Public School, Velachery</option>
            <option value="Jawahar Vidyalaya">Chettinad Vidyashram</option>
            <option value="Jawahar Vidyalaya">Bhavan's Rajaji Vidyashram</option>
            <option value="Jawahar Vidyalaya">Bala Vidya Mandir, Adyar</option>
            <option value="Jawahar Vidyalaya">Vidya Mandir Senior Secondary School, Mylapore</option>
            <option value="Jawahar Vidyalaya">Little Shine Senior Secondary School </option>
            
        </select>
        
        <input type="submit" name="submit" value="Register">
    </form>

    <h2>View Scores by School</h2>

    <form action="index.php?page=submit" method="post">
        <label for="selected_school">Select School:</label>
        <select name="selected_school" id="selected_school" required>
            <option value="">Select your school</option>
            <option value="Alpha School">Alpha School</option>
            <option value="Jai Gopal Garodia">Jai Gopal Garodia</option>
            <option value="Jawahar Vidyalaya">Jawahar Vidyalaya</option>
            <option value="Jawahar Vidyalaya">Padma Seshadri Bala Bhavan (PSBB)</option>
            <option value="Jawahar Vidyalaya">Kendriya Vidyalaya, IIT Campus</option>
            <option value="Jawahar Vidyalaya">DAV Public School, Velachery</option>
            <option value="Jawahar Vidyalaya">Chettinad Vidyashram</option>
            <option value="Jawahar Vidyalaya">Bhavan's Rajaji Vidyashram</option>
            <option value="Jawahar Vidyalaya">Bala Vidya Mandir, Adyar</option>
            <option value="Jawahar Vidyalaya">Vidya Mandir Senior Secondary School, Mylapore</option>
            <option value="Jawahar Vidyalaya">Little Shine Senior Secondary School </option>
        </select>
        
        <input type="submit" name="view_scores" value="View Scores">
    </form>
</div>

</body>
</html>
