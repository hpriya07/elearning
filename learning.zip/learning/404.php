<?php include('header.php'); ?>

			<div id="page-menu-wrap">


			</div>

		</div><!-- #page-menu end -->


		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="nobottommargin">
						<div class="error404 center">404</div>
					</div>

				</div>

			</div>

		</section><!-- #content end -->

<?php include('footer.php'); ?>