<?php include("header.php");

	if(isset($_GET['id'])){

		$sendId=$_GET['id'];
	}

 ?>
		<!-- Content
		============================================= -->



		<div id="page-menu">

			<div id="page-menu-wrap">

			</div>

		</div><!-- #page-menu end -->

<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- ===============Post Content============= -->
					<div class="postcontent nobottommargin clearfix">

						<!-- ===================Posts============== -->
						<div id="posts">

				// Watch Code From Video 1
							


							

						</div><!-- #posts end -->

						
					</div><!-- .postcontent end -->


<!--**************************************************************************** -->

				<div id="posts" class="post-grid grid-container clearfix nobottommargin nobottommargin">

				<!-- php code -->

				// Watch Code From Video 2
		
						</div>
					</div><!-- #posts end -->
<!--**************************************************************-->
	
				</div> <!-- container -->

		</section><!-- #content end -->

<?php include("footer.php"); ?>