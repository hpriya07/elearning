<?php include("header.php"); ?>

<!-- Page Sub Menu
		============================================= -->
		<div id="page-menu">

			<div id="page-menu-wrap">

			</div>

		</div><!-- #page-menu end -->


		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Post Content
					============================================= -->
					<div class="nobottommargin clearfix">

					
					<div class="panel panel-default">
  						<div class="panel-heading">
    						<h3 class="panel-title">Copyrights &copy; </h3>
  						</div>
  						<div class="panel-body">
    						 
    						 <h1>Copyright Ordinance, 1962</h1>
    						 <strong>Copyrights © 2022 All Rights Reserved by Exceptional Programmers.</strong>
    						 <p>
    						 	According to section 10 copyright subsists in literary works (including computer programs).
    						 </p>
    						 
    						 <h3>Meaning of copyright</h3>
    						 <p>Copyright means inter alia the exclusive right<br>
    						 	<ul class="list-group">
  									<li class="list-group-item">To reproduce the work</li>
  									<li class="list-group-item">To publish the work</li>
 									<li class="list-group-item">To perform or broadcast the work</li>
 									<li class="list-group-item">To make any translation or adaption of the work (for details see s. 3).
								</ul>

    						 </p>

    						 <h6 class="center">We are observing your activities.</h6>
    						 <h4 class="center">Contact us and come to fly with us </h4>



  						</div>
					</div>





</div>
</div>
</div>
</section>


<?php include("footer.php"); ?>